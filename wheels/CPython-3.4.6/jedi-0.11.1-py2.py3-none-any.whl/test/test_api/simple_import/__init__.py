from simple_import import module


def in_function():
    from simple_import import module2
