version_info = (4, 2, 2)
__version__ = '.'.join(map(str, version_info))
