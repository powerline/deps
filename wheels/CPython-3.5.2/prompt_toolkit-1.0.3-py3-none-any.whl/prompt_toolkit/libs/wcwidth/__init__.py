" wcwidth module, https://github.com/jquast/wcwidth "
from .wcwidth import (
    wcwidth,
    wcswidth,
)

__all__ = [
    'wcwidth',
    'wcswidth',
]
