# progress.py show progress bars for some actions
#
# Copyright (C) 2010 Augie Fackler <durin42@gmail.com>
#
# This software may be used and distributed according to the terms of the
# GNU General Public License version 2 or any later version.

"""show progress bars for some actions (DEPRECATED)

This extension has been merged into core, you can remove it from your config.
See hg help config.progress for configuration options.
"""
