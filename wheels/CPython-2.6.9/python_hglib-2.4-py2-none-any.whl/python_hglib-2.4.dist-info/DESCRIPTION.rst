python-hglib
============

python-hglib is a library with a fast, convenient interface to Mercurial.
It uses Mercurial's command server for communication with hg.

Installation is standard:

  $ python setup.py install


